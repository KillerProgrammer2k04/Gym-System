﻿-- Create temp tables to hold sample names and addresses
CREATE TABLE #FirstNames (Name NVARCHAR(50));
CREATE TABLE #LastNames (Name NVARCHAR(50));
CREATE TABLE #Addresses (Address NVARCHAR(100));

-- Insert sample first names
INSERT INTO #FirstNames (Name) VALUES ('Bil'), ('Dimitris'), ('Nikolaos'), ('Maria'), ('George'), ('Aggeliki'), ('Elisavet'), ('John'), ('Christos'), ('Sophia');

-- Insert sample last names
INSERT INTO #LastNames (Name) VALUES ('Papadopoulos'), ('Kastanos'), ('Kutakos'), ('Lagos'), ('Antoniou'), ('Simos'), ('Mantsios'), ('Fragkos'), ('Hatzakis'), ('Stamatiou');

-- Insert sample addresses
INSERT INTO #Addresses (Address) VALUES 
('124 Papanastasiou St'), ('23 Iervn Politehniou Ave'), ('322 Ivanninvn St'), ('101 Olymbou St'), ('202 Mstrogianni St'), 
('303 Agias Ave'), ('404 Fragkou St'), ('122 Nikis Ave'), ('231 Nirvana St'), ('36 Nikitara St');

-- Generate random Staff records
INSERT INTO Staffs (StaffID, FirstName, LastName, Username, Email, Password, Gender, YearOfBirth, Address, Phone)
SELECT TOP 10 
    NEWID(), 
    f.Name, 
    l.Name, 
    CONCAT(LEFT(f.Name, 1), l.Name), 
    CONCAT(LEFT(f.Name, 1), l.Name, '@gmail.com'), 
    LEFT(CONVERT(varchar(255), NEWID()), 8), 
    CASE WHEN (ABS(CHECKSUM(NEWID())) % 2) = 0 THEN 'MALE' ELSE 'FEMALE' END, 
    1970 + ABS(CHECKSUM(NEWID()) % 30), 
    a.Address, 
    CONCAT('555-', RIGHT(ABS(CHECKSUM(NEWID())), 7))
FROM #FirstNames f, #LastNames l, #Addresses a
ORDER BY NEWID();

-- Generate random Customer records
INSERT INTO Customers (CustomerID, FirstName, LastName, YearOfBirth, Address, Phone, CreditCard, Gender, Height, Weight)
SELECT TOP 50 
    NEWID(), 
    f.Name, 
    l.Name, 
    1970 + ABS(CHECKSUM(NEWID()) % 30), 
    a.Address, 
    CONCAT('555-', RIGHT(ABS(CHECKSUM(NEWID())), 7)), 
    LEFT(CONVERT(varchar(255), NEWID()), 16), 
    CASE WHEN (ABS(CHECKSUM(NEWID())) % 2) = 0 THEN 'MALE' ELSE 'FEMALE' END, 
    150 + ABS(CHECKSUM(NEWID()) % 50), 
    50 + ABS(CHECKSUM(NEWID()) % 50)
FROM #FirstNames f, #LastNames l, #Addresses a
ORDER BY NEWID();

-- Generate random Trainer records
INSERT INTO Trainers (TrainerID, FirstName, LastName, Gender, YearOfBirth, Address, Phone)
SELECT TOP 20 
    NEWID(), 
    f.Name, 
    l.Name, 
    CASE WHEN (ABS(CHECKSUM(NEWID())) % 2) = 0 THEN 'MALE' ELSE 'FEMALE' END, 
    1970 + ABS(CHECKSUM(NEWID()) % 30), 
    a.Address, 
    CONCAT('555-', RIGHT(ABS(CHECKSUM(NEWID())), 7))
FROM #FirstNames f, #LastNames l, #Addresses a
ORDER BY NEWID();

-- Generate random Subscription records
INSERT INTO Subscriptions (SubscriptionId, StartDateTime, EndDateTime, CostWithVAT, CustomerID)
SELECT TOP 100 
    NEWID(), 
    DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 365), GETDATE()), 
    DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 365) + 30, GETDATE()), 
    50 + (ABS(CHECKSUM(NEWID()) % 500) * 0.01), 
    CustomerID
FROM Customers
ORDER BY NEWID();

-- Generate random Session records
INSERT INTO Sessions (SessionID, StartDateTime, EndDateTime, TrainerID)
SELECT TOP 50 
    NEWID(), 
    DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 365), GETDATE()), 
    DATEADD(HOUR, 1 + ABS(CHECKSUM(NEWID()) % 3), DATEADD(DAY, ABS(CHECKSUM(NEWID()) % 365), GETDATE())), 
    TrainerID
FROM Trainers
ORDER BY NEWID();

-- Generate random CustomerSession records
INSERT INTO CustomerSessions (SessionID, CustomerID)
SELECT TOP 100 
    S.SessionID, 
    C.CustomerID
FROM Sessions S
CROSS JOIN Customers C
ORDER BY NEWID();

-- Drop the temp tables
DROP TABLE #FirstNames;
DROP TABLE #LastNames;
DROP TABLE #Addresses;

-- Optional: Verify the data
SELECT * FROM Staffs;
SELECT * FROM Customers;
SELECT * FROM Trainers;
SELECT * FROM Subscriptions;
SELECT * FROM Sessions;
SELECT * FROM CustomerSessions;
