﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDB
{
    [Table("Staffs")]
    [PrimaryKey(nameof(StaffID))]
    public class Staff
    {
        [Required]
        [Display(Name = "customer Id")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid StaffID { get; set; } = new Guid();

        [Required]
        [MinLength(1), MaxLength(50, ErrorMessage = "First Name cannot exceed 50 characters")]
        [Display(Name = "First Name")]
        public string? FirstName { get; set; }

        [Required]
        [MinLength(1), MaxLength(50, ErrorMessage = "Last Name cannot exceed 80 characters")]
        [Display(Name = "Last Name")]
        public string? LastName { get; set; }

        [Required]
        [MaxLength(50, ErrorMessage = "Value cannot exceed 50 characters")]
        [MinLength(3, ErrorMessage = "Value cannot be less than 3 characters")]
        public string Username { get; set; } = string.Empty;

        [Required]
        [MaxLength(50, ErrorMessage = "Value cannot exceed 50 characters")]
        public string Email { get; set; } = string.Empty;

        [Required]
        [MaxLength(50, ErrorMessage = "Value cannot exceed 50 characters")]
        public string Password { get; set; } = string.Empty;

        [Required]
        [StringLength(6)]
        public string Gender { get; set; } = string.Empty;

        public int? YearOfBirth { get; set; }

        [StringLength(100)]
        public string? Address { get; set; }

        [StringLength(30)]
        public string? Phone { get; set; }
    }
}
