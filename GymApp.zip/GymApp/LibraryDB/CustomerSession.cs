﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace LibraryDB
{
    [Table("CustomerSessions")]
    [PrimaryKey(nameof(SessionID), nameof(CustomerID))]
    public class CustomerSession
    {
        [Required]
        [Display(Name = "Session Id")]
        public Guid SessionID { get; set; } = new Guid();

        [ForeignKey(nameof(SessionID))]
        public virtual Session? Session { get; set; }

        [Required]
        [Display(Name = "customer Id")]
        public Guid CustomerID { get; set; } = new Guid();

        [ForeignKey(nameof(CustomerID))]
        public virtual Customer? Customer { get; set; }
    }
}
