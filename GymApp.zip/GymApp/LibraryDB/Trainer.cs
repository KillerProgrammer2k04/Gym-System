﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace LibraryDB
{
    [Table("Trainers")]
    [PrimaryKey(nameof(TrainerID))]
    public class Trainer
    {
        [Required]
        [Display(Name = "Trainer Id")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid TrainerID { get; set; } = new Guid();

        [Required]
        [MinLength(1), MaxLength(50, ErrorMessage = "First Name cannot exceed 50 characters")]
        [Display(Name = "First Name")]
        public string? FirstName { get; set; }

        [Required]
        [MinLength(1), MaxLength(50, ErrorMessage = "Last Name cannot exceed 80 characters")]
        [Display(Name = "Last Name")]
        public string? LastName { get; set; }

        [Required]
        [StringLength(6)]
        public string Gender { get; set; } = string.Empty;

        public int? YearOfBirth { get; set; }

        [StringLength(100)]
        public string? Address { get; set; }

        [StringLength(30)]
        public string? Phone { get; set; }
    }
}
