﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDB
{
    [Table("Sessions")]
    [PrimaryKey(nameof(SessionID))]
    public class Session
    {
        [Required]
        [Display(Name = "Session Id")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid SessionID { get; set; } = new Guid();

        [Display(Name = "Star Date Time")]
        public DateTime? StartDateTime { get; set; }

        [Display(Name = "End Date Time")]
        public DateTime? EndDateTime { get; set; }

        public Guid? TrainerID { get; set; }

        // Foreign key relationship to ASP.NET Identity Users
        [ForeignKey(nameof(TrainerID))]
        public virtual Trainer? Trainer { get; set; }
    }
}
