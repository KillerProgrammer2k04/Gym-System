﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryDB
{
    [Comment("Customer Customer")]
    [Table("Customers")]
    [PrimaryKey(nameof(CustomerID))]
    public class Customer
    {
        [Required]
        [Display(Name = "customer Id")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid CustomerID { get; set; } = new Guid();

        [Required]
        [MinLength(1), MaxLength(50, ErrorMessage = "First Name cannot exceed 50 characters")]
        [Display(Name = "First Name")]
        public string? FirstName { get; set; }

        [Required]
        [MinLength(1), MaxLength(50, ErrorMessage = "Last Name cannot exceed 80 characters")]
        [Display(Name = "Last Name")]
        public string? LastName { get; set; }


        public int? YearOfBirth { get; set; }

        [StringLength(100)]
        public string? Address { get; set; }

        [StringLength(30)]
        public string? Phone { get; set; }

        [StringLength(30)]
        public string? CreditCard { get; set; }

        [Required]
        [StringLength(6)]
        public string Gender { get; set; } = string.Empty;

        public double? Height { get; set; } 

        public double? Weight { get; set; } 




    }
}
