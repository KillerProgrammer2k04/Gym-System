﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryDB
{
    [Comment("Customer Subscriptions")]
    [Table("Subscriptions")]
    [PrimaryKey(nameof(SubscriptionId))]
    public class Subscription 
    {
        [Required]
        [MaxLength(10)]
        [Display(Name = "SubscriptionId Id")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid SubscriptionId { get; set; } = new Guid();

        [Display(Name = "Star Date Time")]
        public DateTime? StartDateTime { get; set; }

        [Display(Name = "End Date Time")]
        public DateTime? EndDateTime { get; set; }

        [Comment("Συνολικό κόστος με ΦΠΑ")]
        [Display(Name = "Συνολικό κόστος με ΦΠ")]
        public double CostWithVAT { get; set; } = 0;

        public Guid? CustomerID { get; set; }

        // Foreign key relationship to ASP.NET Identity Users
        [ForeignKey(nameof(CustomerID))]
        public virtual Customer? Customer { get; set; }

    }
}
