﻿namespace WinGymApp
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPassword = new TextBox();
            lbl_password = new Label();
            txtUsername = new TextBox();
            label4 = new Label();
            btb_ok = new Button();
            btn_cancel = new Button();
            SuspendLayout();
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(122, 79);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(209, 23);
            txtPassword.TabIndex = 15;
            // 
            // lbl_password
            // 
            lbl_password.AutoSize = true;
            lbl_password.Location = new Point(42, 84);
            lbl_password.Name = "lbl_password";
            lbl_password.Size = new Size(58, 15);
            lbl_password.TabIndex = 14;
            lbl_password.Text = "Paasword";
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(122, 24);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(209, 23);
            txtUsername.TabIndex = 13;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(42, 27);
            label4.Name = "label4";
            label4.Size = new Size(65, 15);
            label4.TabIndex = 12;
            label4.Text = "User Name";
            // 
            // btb_ok
            // 
            btb_ok.Location = new Point(60, 124);
            btb_ok.Name = "btb_ok";
            btb_ok.Size = new Size(93, 29);
            btb_ok.TabIndex = 16;
            btb_ok.Text = "OK";
            btb_ok.UseVisualStyleBackColor = true;
            btb_ok.Click += btb_ok_Click;
            // 
            // btn_cancel
            // 
            btn_cancel.Location = new Point(219, 124);
            btn_cancel.Name = "btn_cancel";
            btn_cancel.Size = new Size(93, 29);
            btn_cancel.TabIndex = 17;
            btn_cancel.Text = "Cancel";
            btn_cancel.UseVisualStyleBackColor = true;
            btn_cancel.Click += btn_cancel_Click;
            // 
            // FormLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(395, 175);
            Controls.Add(btn_cancel);
            Controls.Add(btb_ok);
            Controls.Add(txtPassword);
            Controls.Add(lbl_password);
            Controls.Add(txtUsername);
            Controls.Add(label4);
            Name = "FormLogin";
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPassword;
        private Label lbl_password;
        private TextBox txtUsername;
        private Label label4;
        private Button btb_ok;
        private Button btn_cancel;
    }
}