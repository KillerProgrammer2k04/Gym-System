﻿namespace WinGymApp
{
    partial class FormTrainer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel2 = new Panel();
            btn_close = new Button();
            btn_delete = new Button();
            btn_save = new Button();
            btn_add = new Button();
            txtLastName = new TextBox();
            label3 = new Label();
            txtFirstName = new TextBox();
            label2 = new Label();
            txtTrainerID = new TextBox();
            label1 = new Label();
            comboGender = new ComboBox();
            txtPhone = new TextBox();
            label10 = new Label();
            txtAddress = new TextBox();
            label9 = new Label();
            txtYearOfBirth = new TextBox();
            label8 = new Label();
            label7 = new Label();
            dataGridViewTrainers = new DataGridView();
            trainerIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            firstNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            lastNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            genderDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            yearOfBirthDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            addressDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            phoneDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            trainerBindingSource = new BindingSource(components);
            panel1 = new Panel();
            txt_search_firstName = new TextBox();
            label11 = new Label();
            txt_search_lastName = new TextBox();
            label5 = new Label();
            btn_search = new Button();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewTrainers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trainerBindingSource).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveCaption;
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(btn_close);
            panel2.Controls.Add(btn_delete);
            panel2.Controls.Add(btn_save);
            panel2.Controls.Add(btn_add);
            panel2.Location = new Point(12, 1);
            panel2.Name = "panel2";
            panel2.Size = new Size(735, 45);
            panel2.TabIndex = 26;
            // 
            // btn_close
            // 
            btn_close.Location = new Point(590, 3);
            btn_close.Name = "btn_close";
            btn_close.Size = new Size(101, 32);
            btn_close.TabIndex = 4;
            btn_close.Text = "Close";
            btn_close.UseVisualStyleBackColor = true;
            btn_close.Click += btn_close_Click;
            // 
            // btn_delete
            // 
            btn_delete.Location = new Point(414, 3);
            btn_delete.Name = "btn_delete";
            btn_delete.Size = new Size(101, 32);
            btn_delete.TabIndex = 3;
            btn_delete.Text = "Delete";
            btn_delete.UseVisualStyleBackColor = true;
            btn_delete.Click += btn_delete_Click;
            // 
            // btn_save
            // 
            btn_save.Location = new Point(225, 3);
            btn_save.Name = "btn_save";
            btn_save.Size = new Size(101, 32);
            btn_save.TabIndex = 2;
            btn_save.Text = "Save";
            btn_save.UseVisualStyleBackColor = true;
            btn_save.Click += btn_save_Click;
            // 
            // btn_add
            // 
            btn_add.Location = new Point(38, 3);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(101, 32);
            btn_add.TabIndex = 1;
            btn_add.Text = "Add New";
            btn_add.UseVisualStyleBackColor = true;
            btn_add.Click += btn_add_Click;
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(120, 173);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(191, 23);
            txtLastName.TabIndex = 32;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(40, 176);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 31;
            label3.Text = "Last Name";
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(120, 119);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(191, 23);
            txtFirstName.TabIndex = 30;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(40, 122);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 29;
            label2.Text = "First Name";
            // 
            // txtTrainerID
            // 
            txtTrainerID.Location = new Point(120, 71);
            txtTrainerID.Name = "txtTrainerID";
            txtTrainerID.Size = new Size(191, 23);
            txtTrainerID.TabIndex = 28;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(40, 74);
            label1.Name = "label1";
            label1.Size = new Size(45, 15);
            label1.TabIndex = 27;
            label1.Text = "Staff ID";
            // 
            // comboGender
            // 
            comboGender.DisplayMember = "Gender";
            comboGender.FormattingEnabled = true;
            comboGender.Location = new Point(474, 71);
            comboGender.Name = "comboGender";
            comboGender.Size = new Size(191, 23);
            comboGender.TabIndex = 40;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(474, 230);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(191, 23);
            txtPhone.TabIndex = 39;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(419, 230);
            label10.Name = "label10";
            label10.Size = new Size(41, 15);
            label10.TabIndex = 38;
            label10.Text = "Phone";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(474, 178);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(191, 23);
            txtAddress.TabIndex = 37;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(419, 181);
            label9.Name = "label9";
            label9.Size = new Size(49, 15);
            label9.TabIndex = 36;
            label9.Text = "Address";
            // 
            // txtYearOfBirth
            // 
            txtYearOfBirth.Location = new Point(474, 119);
            txtYearOfBirth.Name = "txtYearOfBirth";
            txtYearOfBirth.Size = new Size(191, 23);
            txtYearOfBirth.TabIndex = 35;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(393, 122);
            label8.Name = "label8";
            label8.Size = new Size(71, 15);
            label8.TabIndex = 34;
            label8.Text = "Year of Birth";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(419, 71);
            label7.Name = "label7";
            label7.Size = new Size(45, 15);
            label7.TabIndex = 33;
            label7.Text = "Gender";
            // 
            // dataGridViewTrainers
            // 
            dataGridViewTrainers.AutoGenerateColumns = false;
            dataGridViewTrainers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewTrainers.Columns.AddRange(new DataGridViewColumn[] { trainerIDDataGridViewTextBoxColumn, firstNameDataGridViewTextBoxColumn, lastNameDataGridViewTextBoxColumn, genderDataGridViewTextBoxColumn, yearOfBirthDataGridViewTextBoxColumn, addressDataGridViewTextBoxColumn, phoneDataGridViewTextBoxColumn });
            dataGridViewTrainers.DataSource = trainerBindingSource;
            dataGridViewTrainers.Location = new Point(12, 337);
            dataGridViewTrainers.Name = "dataGridViewTrainers";
            dataGridViewTrainers.Size = new Size(735, 267);
            dataGridViewTrainers.TabIndex = 42;
            // 
            // trainerIDDataGridViewTextBoxColumn
            // 
            trainerIDDataGridViewTextBoxColumn.DataPropertyName = "TrainerID";
            trainerIDDataGridViewTextBoxColumn.HeaderText = "TrainerID";
            trainerIDDataGridViewTextBoxColumn.Name = "trainerIDDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // yearOfBirthDataGridViewTextBoxColumn
            // 
            yearOfBirthDataGridViewTextBoxColumn.DataPropertyName = "YearOfBirth";
            yearOfBirthDataGridViewTextBoxColumn.HeaderText = "YearOfBirth";
            yearOfBirthDataGridViewTextBoxColumn.Name = "yearOfBirthDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            addressDataGridViewTextBoxColumn.HeaderText = "Address";
            addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
            phoneDataGridViewTextBoxColumn.HeaderText = "Phone";
            phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            // 
            // trainerBindingSource
            // 
            trainerBindingSource.DataSource = typeof(LibraryDB.Trainer);
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(txt_search_firstName);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(txt_search_lastName);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(btn_search);
            panel1.Location = new Point(10, 284);
            panel1.Name = "panel1";
            panel1.Size = new Size(735, 45);
            panel1.TabIndex = 43;
            // 
            // txt_search_firstName
            // 
            txt_search_firstName.Location = new Point(91, 12);
            txt_search_firstName.Name = "txt_search_firstName";
            txt_search_firstName.Size = new Size(191, 23);
            txt_search_firstName.TabIndex = 15;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(21, 15);
            label11.Name = "label11";
            label11.Size = new Size(64, 15);
            label11.TabIndex = 14;
            label11.Text = "First Name";
            // 
            // txt_search_lastName
            // 
            txt_search_lastName.Location = new Point(369, 12);
            txt_search_lastName.Name = "txt_search_lastName";
            txt_search_lastName.Size = new Size(191, 23);
            txt_search_lastName.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(300, 15);
            label5.Name = "label5";
            label5.Size = new Size(63, 15);
            label5.TabIndex = 8;
            label5.Text = "Last Name";
            // 
            // btn_search
            // 
            btn_search.Location = new Point(578, 11);
            btn_search.Name = "btn_search";
            btn_search.Size = new Size(97, 27);
            btn_search.TabIndex = 0;
            btn_search.Text = "Search";
            btn_search.UseVisualStyleBackColor = true;
            btn_search.Click += btn_search_Click;
            // 
            // FormTrainer
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(754, 612);
            Controls.Add(panel1);
            Controls.Add(dataGridViewTrainers);
            Controls.Add(comboGender);
            Controls.Add(txtPhone);
            Controls.Add(label10);
            Controls.Add(txtAddress);
            Controls.Add(label9);
            Controls.Add(txtYearOfBirth);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(txtLastName);
            Controls.Add(label3);
            Controls.Add(txtFirstName);
            Controls.Add(label2);
            Controls.Add(txtTrainerID);
            Controls.Add(label1);
            Controls.Add(panel2);
            Name = "FormTrainer";
            Text = "Trainer";
            Load += FormTrainer_Load;
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewTrainers).EndInit();
            ((System.ComponentModel.ISupportInitialize)trainerBindingSource).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel2;
        private Button btn_close;
        private Button btn_delete;
        private Button btn_save;
        private Button btn_add;
        private TextBox txtLastName;
        private Label label3;
        private TextBox txtFirstName;
        private Label label2;
        private TextBox txtTrainerID;
        private Label label1;
        private ComboBox comboGender;
        private TextBox txtPhone;
        private Label label10;
        private TextBox txtAddress;
        private Label label9;
        private TextBox txtYearOfBirth;
        private Label label8;
        private Label label7;
        private DataGridView dataGridViewTrainers;
        private DataGridViewTextBoxColumn trainerIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn yearOfBirthDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private BindingSource trainerBindingSource;
        private Panel panel1;
        private TextBox txt_search_firstName;
        private Label label11;
        private TextBox txt_search_lastName;
        private Label label5;
        private Button btn_search;
    }
}