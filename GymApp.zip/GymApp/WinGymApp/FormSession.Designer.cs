﻿namespace WinGymApp
{
    partial class FormSession
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel2 = new Panel();
            btn_close = new Button();
            btn_delete = new Button();
            btn_save = new Button();
            btn_add = new Button();
            txtSessionID = new TextBox();
            label1 = new Label();
            label4 = new Label();
            comboTrainerID = new ComboBox();
            label3 = new Label();
            pickerEndDateTime = new DateTimePicker();
            label2 = new Label();
            pickerStartDateTime = new DateTimePicker();
            panel1 = new Panel();
            picker_searchTo = new DateTimePicker();
            picker_searchFrom = new DateTimePicker();
            label11 = new Label();
            label6 = new Label();
            btn_search = new Button();
            dataGridViewSessions = new DataGridView();
            sessionBindingSource = new BindingSource(components);
            sessionIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            startDateTimeDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            endDateTimeDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            trainerIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            trainerDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSessions).BeginInit();
            ((System.ComponentModel.ISupportInitialize)sessionBindingSource).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveCaption;
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(btn_close);
            panel2.Controls.Add(btn_delete);
            panel2.Controls.Add(btn_save);
            panel2.Controls.Add(btn_add);
            panel2.Location = new Point(12, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(735, 45);
            panel2.TabIndex = 28;
            // 
            // btn_close
            // 
            btn_close.Location = new Point(590, 3);
            btn_close.Name = "btn_close";
            btn_close.Size = new Size(101, 32);
            btn_close.TabIndex = 4;
            btn_close.Text = "Close";
            btn_close.UseVisualStyleBackColor = true;
            btn_close.Click += btn_close_Click;
            // 
            // btn_delete
            // 
            btn_delete.Location = new Point(414, 3);
            btn_delete.Name = "btn_delete";
            btn_delete.Size = new Size(101, 32);
            btn_delete.TabIndex = 3;
            btn_delete.Text = "Delete";
            btn_delete.UseVisualStyleBackColor = true;
            btn_delete.Click += btn_delete_Click;
            // 
            // btn_save
            // 
            btn_save.Location = new Point(225, 3);
            btn_save.Name = "btn_save";
            btn_save.Size = new Size(101, 32);
            btn_save.TabIndex = 2;
            btn_save.Text = "Save";
            btn_save.UseVisualStyleBackColor = true;
            btn_save.Click += btn_save_Click;
            // 
            // btn_add
            // 
            btn_add.Location = new Point(38, 3);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(101, 32);
            btn_add.TabIndex = 1;
            btn_add.Text = "Add New";
            btn_add.UseVisualStyleBackColor = true;
            btn_add.Click += btn_add_Click;
            // 
            // txtSessionID
            // 
            txtSessionID.Location = new Point(112, 81);
            txtSessionID.Name = "txtSessionID";
            txtSessionID.Size = new Size(215, 23);
            txtSessionID.TabIndex = 32;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 84);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 31;
            label1.Text = "Session ID";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 142);
            label4.Name = "label4";
            label4.Size = new Size(42, 15);
            label4.TabIndex = 38;
            label4.Text = "Trainer";
            // 
            // comboTrainerID
            // 
            comboTrainerID.FormattingEnabled = true;
            comboTrainerID.Location = new Point(112, 134);
            comboTrainerID.Name = "comboTrainerID";
            comboTrainerID.Size = new Size(215, 23);
            comboTrainerID.TabIndex = 37;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(411, 147);
            label3.Name = "label3";
            label3.Size = new Size(43, 15);
            label3.TabIndex = 42;
            label3.Text = "Unti to";
            // 
            // pickerEndDateTime
            // 
            pickerEndDateTime.Location = new Point(460, 141);
            pickerEndDateTime.Name = "pickerEndDateTime";
            pickerEndDateTime.Size = new Size(233, 23);
            pickerEndDateTime.TabIndex = 41;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(392, 82);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 40;
            label2.Text = "Start From";
            // 
            // pickerStartDateTime
            // 
            pickerStartDateTime.Location = new Point(460, 76);
            pickerStartDateTime.Name = "pickerStartDateTime";
            pickerStartDateTime.Size = new Size(233, 23);
            pickerStartDateTime.TabIndex = 39;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(picker_searchTo);
            panel1.Controls.Add(picker_searchFrom);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(btn_search);
            panel1.Location = new Point(12, 198);
            panel1.Name = "panel1";
            panel1.Size = new Size(735, 60);
            panel1.TabIndex = 45;
            // 
            // picker_searchTo
            // 
            picker_searchTo.Location = new Point(272, 32);
            picker_searchTo.Name = "picker_searchTo";
            picker_searchTo.Size = new Size(233, 23);
            picker_searchTo.TabIndex = 33;
            // 
            // picker_searchFrom
            // 
            picker_searchFrom.Location = new Point(19, 32);
            picker_searchFrom.Name = "picker_searchFrom";
            picker_searchFrom.Size = new Size(233, 23);
            picker_searchFrom.TabIndex = 32;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(75, 8);
            label11.Name = "label11";
            label11.Size = new Size(85, 15);
            label11.TabIndex = 14;
            label11.Text = "Start From Day";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(323, 8);
            label6.Name = "label6";
            label6.Size = new Size(113, 15);
            label6.TabIndex = 8;
            label6.Text = "Until Start From Day";
            // 
            // btn_search
            // 
            btn_search.Location = new Point(595, 28);
            btn_search.Name = "btn_search";
            btn_search.Size = new Size(97, 27);
            btn_search.TabIndex = 0;
            btn_search.Text = "Search";
            btn_search.UseVisualStyleBackColor = true;
            btn_search.Click += btn_search_Click;
            // 
            // dataGridViewSessions
            // 
            dataGridViewSessions.AutoGenerateColumns = false;
            dataGridViewSessions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewSessions.Columns.AddRange(new DataGridViewColumn[] { sessionIDDataGridViewTextBoxColumn, startDateTimeDataGridViewTextBoxColumn, endDateTimeDataGridViewTextBoxColumn, trainerIDDataGridViewTextBoxColumn, trainerDataGridViewTextBoxColumn });
            dataGridViewSessions.DataSource = sessionBindingSource;
            dataGridViewSessions.Location = new Point(12, 277);
            dataGridViewSessions.Name = "dataGridViewSessions";
            dataGridViewSessions.Size = new Size(735, 268);
            dataGridViewSessions.TabIndex = 46;
            // 
            // sessionBindingSource
            // 
            sessionBindingSource.DataSource = typeof(LibraryDB.Session);
            // 
            // sessionIDDataGridViewTextBoxColumn
            // 
            sessionIDDataGridViewTextBoxColumn.DataPropertyName = "SessionID";
            sessionIDDataGridViewTextBoxColumn.HeaderText = "SessionID";
            sessionIDDataGridViewTextBoxColumn.Name = "sessionIDDataGridViewTextBoxColumn";
            // 
            // startDateTimeDataGridViewTextBoxColumn
            // 
            startDateTimeDataGridViewTextBoxColumn.DataPropertyName = "StartDateTime";
            startDateTimeDataGridViewTextBoxColumn.HeaderText = "StartDateTime";
            startDateTimeDataGridViewTextBoxColumn.Name = "startDateTimeDataGridViewTextBoxColumn";
            // 
            // endDateTimeDataGridViewTextBoxColumn
            // 
            endDateTimeDataGridViewTextBoxColumn.DataPropertyName = "EndDateTime";
            endDateTimeDataGridViewTextBoxColumn.HeaderText = "EndDateTime";
            endDateTimeDataGridViewTextBoxColumn.Name = "endDateTimeDataGridViewTextBoxColumn";
            // 
            // trainerIDDataGridViewTextBoxColumn
            // 
            trainerIDDataGridViewTextBoxColumn.DataPropertyName = "TrainerID";
            trainerIDDataGridViewTextBoxColumn.HeaderText = "TrainerID";
            trainerIDDataGridViewTextBoxColumn.Name = "trainerIDDataGridViewTextBoxColumn";
            // 
            // trainerDataGridViewTextBoxColumn
            // 
            trainerDataGridViewTextBoxColumn.DataPropertyName = "Trainer";
            trainerDataGridViewTextBoxColumn.HeaderText = "Trainer";
            trainerDataGridViewTextBoxColumn.Name = "trainerDataGridViewTextBoxColumn";
            // 
            // FormSession
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(761, 546);
            Controls.Add(dataGridViewSessions);
            Controls.Add(panel1);
            Controls.Add(label3);
            Controls.Add(pickerEndDateTime);
            Controls.Add(label2);
            Controls.Add(pickerStartDateTime);
            Controls.Add(label4);
            Controls.Add(comboTrainerID);
            Controls.Add(txtSessionID);
            Controls.Add(label1);
            Controls.Add(panel2);
            Name = "FormSession";
            Text = "Session";
            Load += FormSession_Load;
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSessions).EndInit();
            ((System.ComponentModel.ISupportInitialize)sessionBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel2;
        private Button btn_close;
        private Button btn_delete;
        private Button btn_save;
        private Button btn_add;
        private TextBox txtSessionID;
        private Label label1;
        private Label label4;
        private ComboBox comboTrainerID;
        private Label label3;
        private DateTimePicker pickerEndDateTime;
        private Label label2;
        private DateTimePicker pickerStartDateTime;
        private Panel panel1;
        private DateTimePicker picker_searchTo;
        private DateTimePicker picker_searchFrom;
        private Label label11;
        private Label label6;
        private Button btn_search;
        private DataGridView dataGridViewSessions;
        private DataGridViewTextBoxColumn sessionIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn startDateTimeDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn endDateTimeDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn trainerIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn trainerDataGridViewTextBoxColumn;
        private BindingSource sessionBindingSource;
    }
}