﻿namespace WinGymApp
{
    partial class FormStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            txt_search_email = new TextBox();
            staffBindingSource = new BindingSource(components);
            label11 = new Label();
            txt_search_lastname = new TextBox();
            label5 = new Label();
            btn_search = new Button();
            dataGridViewStaffs = new DataGridView();
            staffIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            firstNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            lastNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            usernameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            emailDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            passwordDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            genderDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            yearOfBirthDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            addressDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            phoneDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            label1 = new Label();
            txtStaffID = new TextBox();
            txtFirstName = new TextBox();
            label2 = new Label();
            txtLastName = new TextBox();
            label3 = new Label();
            txtUsername = new TextBox();
            label4 = new Label();
            txtPassword = new TextBox();
            lbl_password = new Label();
            txtEmail = new TextBox();
            label6 = new Label();
            label7 = new Label();
            txtYearOfBirth = new TextBox();
            label8 = new Label();
            txtAddress = new TextBox();
            label9 = new Label();
            txtPhone = new TextBox();
            label10 = new Label();
            comboGender = new ComboBox();
            panel2 = new Panel();
            btn_close = new Button();
            btn_delete = new Button();
            btn_save = new Button();
            btn_add = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)staffBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStaffs).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(txt_search_email);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(txt_search_lastname);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(btn_search);
            panel1.Location = new Point(2, 329);
            panel1.Name = "panel1";
            panel1.Size = new Size(735, 45);
            panel1.TabIndex = 0;
            // 
            // txt_search_email
            // 
            txt_search_email.DataBindings.Add(new Binding("DataContext", staffBindingSource, "Email", true));
            txt_search_email.Location = new Point(369, 15);
            txt_search_email.Name = "txt_search_email";
            txt_search_email.Size = new Size(191, 23);
            txt_search_email.TabIndex = 15;
            // 
            // staffBindingSource
            // 
            staffBindingSource.DataSource = typeof(LibraryDB.Staff);
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(314, 18);
            label11.Name = "label11";
            label11.Size = new Size(36, 15);
            label11.TabIndex = 14;
            label11.Text = "Email";
            // 
            // txt_search_lastname
            // 
            txt_search_lastname.DataBindings.Add(new Binding("DataContext", staffBindingSource, "LastName", true));
            txt_search_lastname.Location = new Point(102, 12);
            txt_search_lastname.Name = "txt_search_lastname";
            txt_search_lastname.Size = new Size(191, 23);
            txt_search_lastname.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(22, 15);
            label5.Name = "label5";
            label5.Size = new Size(63, 15);
            label5.TabIndex = 8;
            label5.Text = "Last Name";
            // 
            // btn_search
            // 
            btn_search.Location = new Point(578, 11);
            btn_search.Name = "btn_search";
            btn_search.Size = new Size(97, 27);
            btn_search.TabIndex = 0;
            btn_search.Text = "Search";
            btn_search.UseVisualStyleBackColor = true;
            btn_search.Click += btn_search_Click;
            // 
            // dataGridViewStaffs
            // 
            dataGridViewStaffs.AutoGenerateColumns = false;
            dataGridViewStaffs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewStaffs.Columns.AddRange(new DataGridViewColumn[] { staffIDDataGridViewTextBoxColumn, firstNameDataGridViewTextBoxColumn, lastNameDataGridViewTextBoxColumn, usernameDataGridViewTextBoxColumn, emailDataGridViewTextBoxColumn, passwordDataGridViewTextBoxColumn, genderDataGridViewTextBoxColumn, yearOfBirthDataGridViewTextBoxColumn, addressDataGridViewTextBoxColumn, phoneDataGridViewTextBoxColumn });
            dataGridViewStaffs.DataSource = staffBindingSource;
            dataGridViewStaffs.Location = new Point(2, 380);
            dataGridViewStaffs.Name = "dataGridViewStaffs";
            dataGridViewStaffs.Size = new Size(735, 252);
            dataGridViewStaffs.TabIndex = 1;
            // 
            // staffIDDataGridViewTextBoxColumn
            // 
            staffIDDataGridViewTextBoxColumn.DataPropertyName = "StaffID";
            staffIDDataGridViewTextBoxColumn.HeaderText = "StaffID";
            staffIDDataGridViewTextBoxColumn.Name = "staffIDDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            // 
            // emailDataGridViewTextBoxColumn
            // 
            emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            emailDataGridViewTextBoxColumn.HeaderText = "Email";
            emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // yearOfBirthDataGridViewTextBoxColumn
            // 
            yearOfBirthDataGridViewTextBoxColumn.DataPropertyName = "YearOfBirth";
            yearOfBirthDataGridViewTextBoxColumn.HeaderText = "YearOfBirth";
            yearOfBirthDataGridViewTextBoxColumn.Name = "yearOfBirthDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            addressDataGridViewTextBoxColumn.HeaderText = "Address";
            addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
            phoneDataGridViewTextBoxColumn.HeaderText = "Phone";
            phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(25, 88);
            label1.Name = "label1";
            label1.Size = new Size(45, 15);
            label1.TabIndex = 2;
            label1.Text = "Staff ID";
            // 
            // txtStaffID
            // 
            txtStaffID.DataBindings.Add(new Binding("DataContext", staffBindingSource, "StaffID", true));
            txtStaffID.Location = new Point(105, 85);
            txtStaffID.Name = "txtStaffID";
            txtStaffID.Size = new Size(191, 23);
            txtStaffID.TabIndex = 3;
            // 
            // txtFirstName
            // 
            txtFirstName.DataBindings.Add(new Binding("DataContext", staffBindingSource, "FirstName", true));
            txtFirstName.Location = new Point(105, 133);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(191, 23);
            txtFirstName.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(25, 136);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 4;
            label2.Text = "First Name";
            // 
            // txtLastName
            // 
            txtLastName.DataBindings.Add(new Binding("DataContext", staffBindingSource, "LastName", true));
            txtLastName.Location = new Point(105, 187);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(191, 23);
            txtLastName.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(25, 190);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 6;
            label3.Text = "Last Name";
            // 
            // txtUsername
            // 
            txtUsername.DataBindings.Add(new Binding("DataContext", staffBindingSource, "Username", true));
            txtUsername.Location = new Point(105, 243);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(191, 23);
            txtUsername.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(25, 246);
            label4.Name = "label4";
            label4.Size = new Size(65, 15);
            label4.TabIndex = 8;
            label4.Text = "User Name";
            // 
            // txtPassword
            // 
            txtPassword.DataBindings.Add(new Binding("DataContext", staffBindingSource, "Password", true));
            txtPassword.Location = new Point(105, 298);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(191, 23);
            txtPassword.TabIndex = 11;
            // 
            // lbl_password
            // 
            lbl_password.AutoSize = true;
            lbl_password.Location = new Point(25, 303);
            lbl_password.Name = "lbl_password";
            lbl_password.Size = new Size(58, 15);
            lbl_password.TabIndex = 10;
            lbl_password.Text = "Paasword";
            // 
            // txtEmail
            // 
            txtEmail.DataBindings.Add(new Binding("DataContext", staffBindingSource, "Email", true));
            txtEmail.Location = new Point(453, 80);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(191, 23);
            txtEmail.TabIndex = 13;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(398, 83);
            label6.Name = "label6";
            label6.Size = new Size(36, 15);
            label6.TabIndex = 12;
            label6.Text = "Email";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(398, 139);
            label7.Name = "label7";
            label7.Size = new Size(45, 15);
            label7.TabIndex = 14;
            label7.Text = "Gender";
            // 
            // txtYearOfBirth
            // 
            txtYearOfBirth.DataBindings.Add(new Binding("DataContext", staffBindingSource, "YearOfBirth", true));
            txtYearOfBirth.Location = new Point(453, 187);
            txtYearOfBirth.Name = "txtYearOfBirth";
            txtYearOfBirth.Size = new Size(191, 23);
            txtYearOfBirth.TabIndex = 17;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(372, 190);
            label8.Name = "label8";
            label8.Size = new Size(71, 15);
            label8.TabIndex = 16;
            label8.Text = "Year of Birth";
            // 
            // txtAddress
            // 
            txtAddress.DataBindings.Add(new Binding("DataContext", staffBindingSource, "Address", true));
            txtAddress.Location = new Point(453, 246);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(191, 23);
            txtAddress.TabIndex = 19;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(398, 249);
            label9.Name = "label9";
            label9.Size = new Size(49, 15);
            label9.TabIndex = 18;
            label9.Text = "Address";
            // 
            // txtPhone
            // 
            txtPhone.DataBindings.Add(new Binding("DataContext", staffBindingSource, "Phone", true));
            txtPhone.Location = new Point(453, 298);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(191, 23);
            txtPhone.TabIndex = 21;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(398, 298);
            label10.Name = "label10";
            label10.Size = new Size(41, 15);
            label10.TabIndex = 20;
            label10.Text = "Phone";
            // 
            // comboGender
            // 
            comboGender.DataSource = staffBindingSource;
            comboGender.DisplayMember = "Gender";
            comboGender.FormattingEnabled = true;
            comboGender.Location = new Point(453, 139);
            comboGender.Name = "comboGender";
            comboGender.Size = new Size(191, 23);
            comboGender.TabIndex = 24;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveCaption;
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(btn_close);
            panel2.Controls.Add(btn_delete);
            panel2.Controls.Add(btn_save);
            panel2.Controls.Add(btn_add);
            panel2.Location = new Point(2, 2);
            panel2.Name = "panel2";
            panel2.Size = new Size(735, 45);
            panel2.TabIndex = 25;
            // 
            // btn_close
            // 
            btn_close.Location = new Point(590, 3);
            btn_close.Name = "btn_close";
            btn_close.Size = new Size(101, 32);
            btn_close.TabIndex = 4;
            btn_close.Text = "Close";
            btn_close.UseVisualStyleBackColor = true;
            btn_close.Click += btn_close_Click;
            // 
            // btn_delete
            // 
            btn_delete.Location = new Point(414, 3);
            btn_delete.Name = "btn_delete";
            btn_delete.Size = new Size(101, 32);
            btn_delete.TabIndex = 3;
            btn_delete.Text = "Delete";
            btn_delete.UseVisualStyleBackColor = true;
            btn_delete.Click += btn_delete_Click;
            // 
            // btn_save
            // 
            btn_save.Location = new Point(225, 3);
            btn_save.Name = "btn_save";
            btn_save.Size = new Size(101, 32);
            btn_save.TabIndex = 2;
            btn_save.Text = "Save";
            btn_save.UseVisualStyleBackColor = true;
            btn_save.Click += btn_save_Click;
            // 
            // btn_add
            // 
            btn_add.Location = new Point(38, 3);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(101, 32);
            btn_add.TabIndex = 1;
            btn_add.Text = "Add New";
            btn_add.UseVisualStyleBackColor = true;
            btn_add.Click += btn_add_Click;
            // 
            // FormStaff
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(742, 644);
            Controls.Add(panel2);
            Controls.Add(comboGender);
            Controls.Add(txtPhone);
            Controls.Add(label10);
            Controls.Add(txtAddress);
            Controls.Add(label9);
            Controls.Add(txtYearOfBirth);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(txtEmail);
            Controls.Add(label6);
            Controls.Add(txtPassword);
            Controls.Add(lbl_password);
            Controls.Add(txtUsername);
            Controls.Add(label4);
            Controls.Add(txtLastName);
            Controls.Add(label3);
            Controls.Add(txtFirstName);
            Controls.Add(label2);
            Controls.Add(txtStaffID);
            Controls.Add(label1);
            Controls.Add(dataGridViewStaffs);
            Controls.Add(panel1);
            Name = "FormStaff";
            Text = " Staff";
            Load += FormStaff_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)staffBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStaffs).EndInit();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private DataGridView dataGridViewStaffs;
        private DataGridViewTextBoxColumn staffIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn yearOfBirthDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private BindingSource staffBindingSource;
        private Label label1;
        private TextBox txtStaffID;
        private TextBox txtFirstName;
        private Label label2;
        private TextBox txtLastName;
        private Label label3;
        private TextBox txtUsername;
        private Label label4;
        private TextBox txtPassword;
        private Label lbl_password;
        private TextBox txtEmail;
        private Label label6;
        private Label label7;
        private TextBox txtYearOfBirth;
        private Label label8;
        private TextBox txtAddress;
        private Label label9;
        private TextBox txtPhone;
        private Label label10;
        private ComboBox comboGender;
        private TextBox txt_search_email;
        private Label label11;
        private TextBox txt_search_lastname;
        private Label label5;
        private Button btn_search;
        private Panel panel2;
        private Button btn_add;
        private Button btn_delete;
        private Button btn_save;
        private Button btn_close;
    }
}