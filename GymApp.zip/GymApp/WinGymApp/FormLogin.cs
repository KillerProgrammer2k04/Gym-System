﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibraryDB;

namespace WinGymApp
{
    public partial class FormLogin : Form
    {
        public bool IsAuthenticated { get; private set; }
        public string LoggedInUser { get; private set; }

        public FormLogin()
        {
            InitializeComponent();
            IsAuthenticated = false;
        }

        private void btb_ok_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            using (var context = new GymDBContext())
            {
                var user = context.Staffs.SingleOrDefault(s => s.Username == username && s.Password == password);
                if (user != null)
                {
                    IsAuthenticated = true;
                    LoggedInUser = username;
                    MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
