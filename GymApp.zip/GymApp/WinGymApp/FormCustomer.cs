﻿using LibraryDB;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WinGymApp
{
    public partial class FormCustomer : Form
    {
        private Customer newCustomer;

        public FormCustomer()
        {
            InitializeComponent();
        }

        private void FormCustomer_Load(object sender, EventArgs e)
        {
            LoadCustomerData();
        }

        private void LoadCustomerData()
        {
            using (var context = new GymDBContext())
            {
                // Fetch data from the Customers table
                var customerData = context.Customers.ToList();

                // Bind the data to the BindingSource
                customerBindingSource.DataSource = customerData;

                // Bind the BindingSource to the DataGridView
                dataGridViewCustomers.DataSource = customerBindingSource;

                // Bind each TextBox to specific fields of the BindingSource
                txtCustomerID.DataBindings.Clear();
                txtFirstName.DataBindings.Clear();
                txtLastName.DataBindings.Clear();
                txtYearOfBirth.DataBindings.Clear();
                txtAddress.DataBindings.Clear();
                txtPhone.DataBindings.Clear();
                txtCreditCard.DataBindings.Clear();
                comboGender.DataBindings.Clear();
                txtHeight.DataBindings.Clear();
                txtWeight.DataBindings.Clear();

                txtCustomerID.DataBindings.Add("Text", customerBindingSource, "CustomerID", true, DataSourceUpdateMode.OnPropertyChanged);
                txtFirstName.DataBindings.Add("Text", customerBindingSource, "FirstName", true, DataSourceUpdateMode.OnPropertyChanged);
                txtLastName.DataBindings.Add("Text", customerBindingSource, "LastName", true, DataSourceUpdateMode.OnPropertyChanged);
                txtYearOfBirth.DataBindings.Add("Text", customerBindingSource, "YearOfBirth", true, DataSourceUpdateMode.OnPropertyChanged);
                txtAddress.DataBindings.Add("Text", customerBindingSource, "Address", true, DataSourceUpdateMode.OnPropertyChanged);
                txtPhone.DataBindings.Add("Text", customerBindingSource, "Phone", true, DataSourceUpdateMode.OnPropertyChanged);
                txtCreditCard.DataBindings.Add("Text", customerBindingSource, "CreditCard", true, DataSourceUpdateMode.OnPropertyChanged);
                comboGender.DataBindings.Add("SelectedItem", customerBindingSource, "Gender", true, DataSourceUpdateMode.OnPropertyChanged);
                txtHeight.DataBindings.Add("Text", customerBindingSource, "Height", true, DataSourceUpdateMode.OnPropertyChanged);
                txtWeight.DataBindings.Add("Text", customerBindingSource, "Weight", true, DataSourceUpdateMode.OnPropertyChanged);

                // Prepare the gender options
                var genderOptions = new List<string> { "MALE", "FEMALE" };

                // Bind the ComboBox to the gender options
                comboGender.DataSource = genderOptions;
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            // Clear the textboxes to prepare for adding a new record
            newCustomer = new Customer();
            customerBindingSource.Add(newCustomer);
            customerBindingSource.MoveLast();

            txtCustomerID.Text = string.Empty;
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtYearOfBirth.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtCreditCard.Text = string.Empty;
            comboGender.SelectedIndex = -1;
            txtHeight.Text = string.Empty;
            txtWeight.Text = string.Empty;

            txtFirstName.Focus();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Add or update the customer records
                    foreach (var customer in customerBindingSource.List.OfType<Customer>())
                    {
                        // Check if CustomerID is empty (new record)
                        if (customer.CustomerID == Guid.Empty)
                        {
                            customer.CustomerID = Guid.NewGuid();
                            context.Customers.Add(customer);
                        }
                        else
                        {
                            context.Customers.Update(customer);
                        }
                    }

                    context.SaveChanges();
                    MessageBox.Show("Data saved successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (ValidationException valEx)
            {
                MessageBox.Show($"A validation error occurred: {valEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the current customer record from the BindingSource
                    var currentCustomer = customerBindingSource.Current as Customer;
                    if (currentCustomer != null)
                    {
                        // Find the customer record in the context
                        var customerToDelete = context.Customers.Find(currentCustomer.CustomerID);
                        if (customerToDelete != null)
                        {
                            // Remove the customer record from the context
                            context.Customers.Remove(customerToDelete);
                            context.SaveChanges();

                            // Remove the customer record from the BindingSource
                            customerBindingSource.RemoveCurrent();

                            MessageBox.Show("Record deleted successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Record not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No record selected to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the search criteria from the textboxes
                    string searchFirstName = txt_search_firstName.Text.Trim();
                    string searchLastName = txt_search_lastName.Text.Trim();

                    // Fetch data from the Customers table with the applied filters
                    var customerData = context.Customers.AsQueryable();

                    if (!string.IsNullOrEmpty(searchFirstName))
                    {
                        customerData = customerData.Where(c => c.FirstName.Contains(searchFirstName));
                    }

                    if (!string.IsNullOrEmpty(searchLastName))
                    {
                        customerData = customerData.Where(c => c.LastName.Contains(searchLastName));
                    }

                    // Bind the filtered data to the BindingSource
                    customerBindingSource.DataSource = customerData.ToList();

                    // Refresh the DataGridView
                    dataGridViewCustomers.DataSource = customerBindingSource;
                    dataGridViewCustomers.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while searching: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
        
    }
}
