namespace WinGymApp
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
            SetButtonsEnabled(false);
        }

        private void btn_staff_Click(object sender, EventArgs e)
        {
            FormStaff frm_staff = new FormStaff();
            frm_staff.ShowDialog();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            using (var loginForm = new FormLogin())
            {
                loginForm.ShowDialog();

                if (loginForm.IsAuthenticated)
                {
                    SetButtonsEnabled(true); // Enable buttons after successful login
                    btn_login.Enabled = false; // Disable the login button
                    MessageBox.Show($"Welcome, {loginForm.LoggedInUser}!", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void SetButtonsEnabled(bool enabled)
        {
            btn_staff.Enabled = enabled;
            btn_logout.Enabled = enabled;
            btn_customer.Enabled = enabled;
            btn_subscription.Enabled = enabled;
            btn_session.Enabled = enabled;
            btn_trainer.Enabled = enabled;
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            SetButtonsEnabled(false); // Disable buttons on logout
            btn_login.Enabled = true; // Enable the login button
        }

        private void btn_customer_Click(object sender, EventArgs e)
        {
            FormCustomer frm_customer = new FormCustomer();
            frm_customer.ShowDialog();
        }

        private void btn_trainer_Click(object sender, EventArgs e)
        {
            FormTrainer frm_trainer = new FormTrainer();
            frm_trainer.ShowDialog();
        }

        private void btn_subscription_Click(object sender, EventArgs e)
        {
            FormSubscription frm_subscription = new FormSubscription();
            frm_subscription.ShowDialog();
        }

        private void btn_session_Click(object sender, EventArgs e)
        {
            FormSession frm_session = new FormSession();
            frm_session.ShowDialog();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
    }
}
