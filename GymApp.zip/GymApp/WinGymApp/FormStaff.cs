﻿using LibraryDB;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WinGymApp
{
    public partial class FormStaff : Form
    {
        private Staff newStaff;
        public FormStaff()
        {
            InitializeComponent();
        }

        private void FormStaff_Load(object sender, EventArgs e)
        {
            LoadStaffData();
        }

        private void LoadStaffData()
        {
            using (var context = new GymDBContext())
            {
                // Fetch data from the Staffs table
                var staffData = context.Staffs.ToList();

                // Bind the data to the BindingSource
                staffBindingSource.DataSource = staffData;

                // Bind the BindingSource to the DataGridView
                dataGridViewStaffs.DataSource = staffBindingSource;

                // Bind each TextBox to specific fields of the BindingSource
                txtStaffID.DataBindings.Clear();
                txtFirstName.DataBindings.Clear();
                txtLastName.DataBindings.Clear();
                txtUsername.DataBindings.Clear();
                txtEmail.DataBindings.Clear();
                txtPassword.DataBindings.Clear();
                comboGender.DataBindings.Clear();
                txtYearOfBirth.DataBindings.Clear();
                txtAddress.DataBindings.Clear();
                txtPhone.DataBindings.Clear();

                txtStaffID.DataBindings.Add("Text", staffBindingSource, "StaffID", true, DataSourceUpdateMode.OnPropertyChanged);
                txtFirstName.DataBindings.Add("Text", staffBindingSource, "FirstName", true, DataSourceUpdateMode.OnPropertyChanged);
                txtLastName.DataBindings.Add("Text", staffBindingSource, "LastName", true, DataSourceUpdateMode.OnPropertyChanged);
                txtUsername.DataBindings.Add("Text", staffBindingSource, "Username", true, DataSourceUpdateMode.OnPropertyChanged);
                txtEmail.DataBindings.Add("Text", staffBindingSource, "Email", true, DataSourceUpdateMode.OnPropertyChanged);
                txtPassword.DataBindings.Add("Text", staffBindingSource, "Password", true, DataSourceUpdateMode.OnPropertyChanged);
                txtYearOfBirth.DataBindings.Add("Text", staffBindingSource, "YearOfBirth", true, DataSourceUpdateMode.OnPropertyChanged);
                txtAddress.DataBindings.Add("Text", staffBindingSource, "Address", true, DataSourceUpdateMode.OnPropertyChanged);
                txtPhone.DataBindings.Add("Text", staffBindingSource, "Phone", true, DataSourceUpdateMode.OnPropertyChanged);

                // Prepare the gender options
                var genderOptions = new List<string> { "MALE", "FEMALE" };

                // Bind the ComboBox to the gender options
                comboGender.DataSource = genderOptions;

                // Bind the ComboBox to the Gender field of  BindingSource
                comboGender.DataBindings.Add("SelectedItem", staffBindingSource, "Gender", true, DataSourceUpdateMode.OnPropertyChanged);
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the search criteria from the textboxes
                    string searchLastName = txt_search_lastname.Text.Trim();
                    string searchEmail = txt_search_email.Text.Trim();

                    // Fetch data from the Staffs table with the applied filters
                    var staffData = context.Staffs.AsQueryable();

                    if (!string.IsNullOrEmpty(searchLastName))
                    {
                        staffData = staffData.Where(s => s.LastName.Contains(searchLastName));
                    }

                    if (!string.IsNullOrEmpty(searchEmail))
                    {
                        staffData = staffData.Where(s => s.Email.Contains(searchEmail));
                    }

                    // Bind the filtered data to the BindingSource
                    staffBindingSource.DataSource = staffData.ToList();

                    // Refresh the DataGridView
                    dataGridViewStaffs.DataSource = staffBindingSource;
                    dataGridViewStaffs.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while searching: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            // Clear the textboxes to prepare for adding a new record
            newStaff = new Staff();
            staffBindingSource.Add(newStaff);
            staffBindingSource.MoveLast();

            txtStaffID.Text = string.Empty;
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtUsername.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPassword.Text = string.Empty;
            comboGender.SelectedIndex = -1;
            txtYearOfBirth.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtPhone.Text = string.Empty;

            txtFirstName.Focus();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Add or update the staff records
                    foreach (var staff in staffBindingSource.List.OfType<Staff>())
                    {
                        // Check if StaffID is empty (new record)
                        if (staff.StaffID == Guid.Empty)
                        {
                            staff.StaffID = Guid.NewGuid();
                            context.Staffs.Add(staff);
                        }
                        else
                        {
                            context.Staffs.Update(staff);
                        }
                    }

                    context.SaveChanges();
                    MessageBox.Show("Data saved successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (ValidationException valEx)
            {
                MessageBox.Show($"A validation error occurred: {valEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the current staff record from the BindingSource
                    var currentStaff = staffBindingSource.Current as Staff;
                    if (currentStaff != null)
                    {
                        // Find the staff record in the context
                        var staffToDelete = context.Staffs.Find(currentStaff.StaffID);
                        if (staffToDelete != null)
                        {
                            // Remove the staff record from the context
                            context.Staffs.Remove(staffToDelete);
                            context.SaveChanges();

                            // Remove the staff record from the BindingSource
                            staffBindingSource.RemoveCurrent();

                            MessageBox.Show("Record deleted successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Record not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No record selected to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
