﻿using LibraryDB;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinGymApp
{
    public partial class FormTrainer : Form
    {
        private Trainer newTrainer;
        public FormTrainer()
        {
            InitializeComponent();
        }

        private void FormTrainer_Load(object sender, EventArgs e)
        {
            LoadTrainerData();
        }

        private void LoadTrainerData()
        {
            using (var context = new GymDBContext())
            {
                // Fetch data from the Trainers table
                var trainerData = context.Trainers.ToList();

                // Bind the data to the BindingSource
                trainerBindingSource.DataSource = trainerData;

                // Bind the BindingSource to the DataGridView
                dataGridViewTrainers.DataSource = trainerBindingSource;

                // Bind each TextBox to specific fields of the BindingSource
                txtTrainerID.DataBindings.Clear();
                txtFirstName.DataBindings.Clear();
                txtLastName.DataBindings.Clear();
                txtYearOfBirth.DataBindings.Clear();
                txtAddress.DataBindings.Clear();
                txtPhone.DataBindings.Clear();
                comboGender.DataBindings.Clear();

                txtTrainerID.DataBindings.Add("Text", trainerBindingSource, "TrainerID", true, DataSourceUpdateMode.OnPropertyChanged);
                txtFirstName.DataBindings.Add("Text", trainerBindingSource, "FirstName", true, DataSourceUpdateMode.OnPropertyChanged);
                txtLastName.DataBindings.Add("Text", trainerBindingSource, "LastName", true, DataSourceUpdateMode.OnPropertyChanged);
                txtYearOfBirth.DataBindings.Add("Text", trainerBindingSource, "YearOfBirth", true, DataSourceUpdateMode.OnPropertyChanged);
                txtAddress.DataBindings.Add("Text", trainerBindingSource, "Address", true, DataSourceUpdateMode.OnPropertyChanged);
                txtPhone.DataBindings.Add("Text", trainerBindingSource, "Phone", true, DataSourceUpdateMode.OnPropertyChanged);

                // Prepare the gender options
                var genderOptions = new List<string> { "MALE", "FEMALE" };

                // Bind the ComboBox to the gender options
                comboGender.DataSource = genderOptions;

                // Bind the ComboBox to the Gender field of BindingSource
                comboGender.DataBindings.Add("SelectedItem", trainerBindingSource, "Gender", true, DataSourceUpdateMode.OnPropertyChanged);
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            // Clear the textboxes to prepare for adding a new record
            newTrainer = new Trainer();
            trainerBindingSource.Add(newTrainer);
            trainerBindingSource.MoveLast();

            txtTrainerID.Text = string.Empty;
            txtFirstName.Text = string.Empty;
            txtLastName.Text = string.Empty;
            txtYearOfBirth.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtPhone.Text = string.Empty;
            comboGender.SelectedIndex = -1;

            txtFirstName.Focus();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Add or update the trainer records
                    foreach (var trainer in trainerBindingSource.List.OfType<Trainer>())
                    {
                        // Check if TrainerID is empty (new record)
                        if (trainer.TrainerID == Guid.Empty)
                        {
                            trainer.TrainerID = Guid.NewGuid();
                            context.Trainers.Add(trainer);
                        }
                        else
                        {
                            context.Trainers.Update(trainer);
                        }
                    }

                    context.SaveChanges();
                    MessageBox.Show("Data saved successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (ValidationException valEx)
            {
                MessageBox.Show($"A validation error occurred: {valEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the current trainer record from the BindingSource
                    var currentTrainer = trainerBindingSource.Current as Trainer;
                    if (currentTrainer != null)
                    {
                        // Find the trainer record in the context
                        var trainerToDelete = context.Trainers.Find(currentTrainer.TrainerID);
                        if (trainerToDelete != null)
                        {
                            // Remove the trainer record from the context
                            context.Trainers.Remove(trainerToDelete);
                            context.SaveChanges();

                            // Remove the trainer record from the BindingSource
                            trainerBindingSource.RemoveCurrent();

                            MessageBox.Show("Record deleted successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Record not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No record selected to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the search criteria from the textboxes
                    string searchFirstName = txt_search_firstName.Text.Trim();
                    string searchLastName = txt_search_lastName.Text.Trim();

                    // Fetch data from the Trainers table with the applied filters
                    var trainerData = context.Trainers.AsQueryable();

                    if (!string.IsNullOrEmpty(searchFirstName))
                    {
                        trainerData = trainerData.Where(t => t.FirstName.Contains(searchFirstName));
                    }

                    if (!string.IsNullOrEmpty(searchLastName))
                    {
                        trainerData = trainerData.Where(t => t.LastName.Contains(searchLastName));
                    }

                    // Bind the filtered data to the BindingSource
                    trainerBindingSource.DataSource = trainerData.ToList();

                    // Refresh the DataGridView
                    dataGridViewTrainers.DataSource = trainerBindingSource;
                    dataGridViewTrainers.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while searching: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
