﻿namespace WinGymApp
{
    partial class FormCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            comboGender = new ComboBox();
            txtPhone = new TextBox();
            label10 = new Label();
            txtAddress = new TextBox();
            label9 = new Label();
            txtYearOfBirth = new TextBox();
            label8 = new Label();
            label7 = new Label();
            txtWeight = new TextBox();
            label6 = new Label();
            txtHeight = new TextBox();
            lbl_password = new Label();
            txtCreditCard = new TextBox();
            label4 = new Label();
            txtLastName = new TextBox();
            label3 = new Label();
            txtFirstName = new TextBox();
            label2 = new Label();
            panel1 = new Panel();
            txt_search_firstName = new TextBox();
            label11 = new Label();
            txt_search_lastName = new TextBox();
            label5 = new Label();
            btn_search = new Button();
            label1 = new Label();
            txtCustomerID = new TextBox();
            dataGridViewCustomers = new DataGridView();
            customerIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            firstNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            lastNameDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            yearOfBirthDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            addressDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            phoneDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            creditCardDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            genderDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            heightDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            weightDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            customerBindingSource = new BindingSource(components);
            panel3 = new Panel();
            btn_close = new Button();
            btn_delete = new Button();
            btn_save = new Button();
            btn_add = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)customerBindingSource).BeginInit();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // comboGender
            // 
            comboGender.FormattingEnabled = true;
            comboGender.Location = new Point(151, 314);
            comboGender.Name = "comboGender";
            comboGender.Size = new Size(191, 23);
            comboGender.TabIndex = 47;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(499, 311);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(191, 23);
            txtPhone.TabIndex = 46;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(444, 311);
            label10.Name = "label10";
            label10.Size = new Size(41, 15);
            label10.TabIndex = 45;
            label10.Text = "Phone";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(499, 259);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(191, 23);
            txtAddress.TabIndex = 44;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(444, 262);
            label9.Name = "label9";
            label9.Size = new Size(49, 15);
            label9.TabIndex = 43;
            label9.Text = "Address";
            // 
            // txtYearOfBirth
            // 
            txtYearOfBirth.Location = new Point(499, 200);
            txtYearOfBirth.Name = "txtYearOfBirth";
            txtYearOfBirth.Size = new Size(191, 23);
            txtYearOfBirth.TabIndex = 42;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(418, 203);
            label8.Name = "label8";
            label8.Size = new Size(71, 15);
            label8.TabIndex = 41;
            label8.Text = "Year of Birth";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(88, 322);
            label7.Name = "label7";
            label7.Size = new Size(45, 15);
            label7.TabIndex = 40;
            label7.Text = "Gender";
            // 
            // txtWeight
            // 
            txtWeight.Location = new Point(499, 154);
            txtWeight.Name = "txtWeight";
            txtWeight.Size = new Size(191, 23);
            txtWeight.TabIndex = 39;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(440, 154);
            label6.Name = "label6";
            label6.Size = new Size(45, 15);
            label6.TabIndex = 38;
            label6.Text = "Weight";
            // 
            // txtHeight
            // 
            txtHeight.Location = new Point(499, 103);
            txtHeight.Name = "txtHeight";
            txtHeight.Size = new Size(191, 23);
            txtHeight.TabIndex = 37;
            // 
            // lbl_password
            // 
            lbl_password.AutoSize = true;
            lbl_password.Location = new Point(440, 106);
            lbl_password.Name = "lbl_password";
            lbl_password.Size = new Size(43, 15);
            lbl_password.TabIndex = 36;
            lbl_password.Text = "Height";
            // 
            // txtCreditCard
            // 
            txtCreditCard.Location = new Point(151, 256);
            txtCreditCard.Name = "txtCreditCard";
            txtCreditCard.Size = new Size(191, 23);
            txtCreditCard.TabIndex = 35;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(71, 259);
            label4.Name = "label4";
            label4.Size = new Size(67, 15);
            label4.TabIndex = 34;
            label4.Text = "Credit Card";
            // 
            // txtLastName
            // 
            txtLastName.Location = new Point(151, 200);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(191, 23);
            txtLastName.TabIndex = 33;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(71, 203);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 32;
            label3.Text = "Last Name";
            // 
            // txtFirstName
            // 
            txtFirstName.Location = new Point(151, 146);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(191, 23);
            txtFirstName.TabIndex = 31;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(71, 149);
            label2.Name = "label2";
            label2.Size = new Size(64, 15);
            label2.TabIndex = 30;
            label2.Text = "First Name";
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(txt_search_firstName);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(txt_search_lastName);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(btn_search);
            panel1.Location = new Point(12, 366);
            panel1.Name = "panel1";
            panel1.Size = new Size(735, 45);
            panel1.TabIndex = 26;
            // 
            // txt_search_firstName
            // 
            txt_search_firstName.Location = new Point(91, 12);
            txt_search_firstName.Name = "txt_search_firstName";
            txt_search_firstName.Size = new Size(191, 23);
            txt_search_firstName.TabIndex = 15;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(21, 15);
            label11.Name = "label11";
            label11.Size = new Size(64, 15);
            label11.TabIndex = 14;
            label11.Text = "First Name";
            // 
            // txt_search_lastName
            // 
            txt_search_lastName.Location = new Point(369, 12);
            txt_search_lastName.Name = "txt_search_lastName";
            txt_search_lastName.Size = new Size(191, 23);
            txt_search_lastName.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(300, 15);
            label5.Name = "label5";
            label5.Size = new Size(63, 15);
            label5.TabIndex = 8;
            label5.Text = "Last Name";
            // 
            // btn_search
            // 
            btn_search.Location = new Point(578, 11);
            btn_search.Name = "btn_search";
            btn_search.Size = new Size(97, 27);
            btn_search.TabIndex = 0;
            btn_search.Text = "Search";
            btn_search.UseVisualStyleBackColor = true;
            btn_search.Click += btn_search_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(71, 101);
            label1.Name = "label1";
            label1.Size = new Size(73, 15);
            label1.TabIndex = 28;
            label1.Text = "Customer ID";
            // 
            // txtCustomerID
            // 
            txtCustomerID.Location = new Point(151, 98);
            txtCustomerID.Name = "txtCustomerID";
            txtCustomerID.Size = new Size(191, 23);
            txtCustomerID.TabIndex = 29;
            // 
            // dataGridViewCustomers
            // 
            dataGridViewCustomers.AutoGenerateColumns = false;
            dataGridViewCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCustomers.Columns.AddRange(new DataGridViewColumn[] { customerIDDataGridViewTextBoxColumn, firstNameDataGridViewTextBoxColumn, lastNameDataGridViewTextBoxColumn, yearOfBirthDataGridViewTextBoxColumn, addressDataGridViewTextBoxColumn, phoneDataGridViewTextBoxColumn, creditCardDataGridViewTextBoxColumn, genderDataGridViewTextBoxColumn, heightDataGridViewTextBoxColumn, weightDataGridViewTextBoxColumn });
            dataGridViewCustomers.DataSource = customerBindingSource;
            dataGridViewCustomers.Location = new Point(12, 417);
            dataGridViewCustomers.Name = "dataGridViewCustomers";
            dataGridViewCustomers.Size = new Size(735, 244);
            dataGridViewCustomers.TabIndex = 49;
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            customerIDDataGridViewTextBoxColumn.DataPropertyName = "CustomerID";
            customerIDDataGridViewTextBoxColumn.HeaderText = "CustomerID";
            customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            // 
            // yearOfBirthDataGridViewTextBoxColumn
            // 
            yearOfBirthDataGridViewTextBoxColumn.DataPropertyName = "YearOfBirth";
            yearOfBirthDataGridViewTextBoxColumn.HeaderText = "YearOfBirth";
            yearOfBirthDataGridViewTextBoxColumn.Name = "yearOfBirthDataGridViewTextBoxColumn";
            // 
            // addressDataGridViewTextBoxColumn
            // 
            addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
            addressDataGridViewTextBoxColumn.HeaderText = "Address";
            addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
            phoneDataGridViewTextBoxColumn.HeaderText = "Phone";
            phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            // 
            // creditCardDataGridViewTextBoxColumn
            // 
            creditCardDataGridViewTextBoxColumn.DataPropertyName = "CreditCard";
            creditCardDataGridViewTextBoxColumn.HeaderText = "CreditCard";
            creditCardDataGridViewTextBoxColumn.Name = "creditCardDataGridViewTextBoxColumn";
            // 
            // genderDataGridViewTextBoxColumn
            // 
            genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            // 
            // heightDataGridViewTextBoxColumn
            // 
            heightDataGridViewTextBoxColumn.DataPropertyName = "Height";
            heightDataGridViewTextBoxColumn.HeaderText = "Height";
            heightDataGridViewTextBoxColumn.Name = "heightDataGridViewTextBoxColumn";
            // 
            // weightDataGridViewTextBoxColumn
            // 
            weightDataGridViewTextBoxColumn.DataPropertyName = "Weight";
            weightDataGridViewTextBoxColumn.HeaderText = "Weight";
            weightDataGridViewTextBoxColumn.Name = "weightDataGridViewTextBoxColumn";
            // 
            // customerBindingSource
            // 
            customerBindingSource.DataSource = typeof(LibraryDB.Customer);
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ActiveCaption;
            panel3.BorderStyle = BorderStyle.Fixed3D;
            panel3.Controls.Add(btn_close);
            panel3.Controls.Add(btn_delete);
            panel3.Controls.Add(btn_save);
            panel3.Controls.Add(btn_add);
            panel3.Location = new Point(12, 12);
            panel3.Name = "panel3";
            panel3.Size = new Size(742, 45);
            panel3.TabIndex = 50;
            // 
            // btn_close
            // 
            btn_close.Location = new Point(590, 3);
            btn_close.Name = "btn_close";
            btn_close.Size = new Size(101, 32);
            btn_close.TabIndex = 4;
            btn_close.Text = "Close";
            btn_close.UseVisualStyleBackColor = true;
            btn_close.Click += btn_close_Click;
            // 
            // btn_delete
            // 
            btn_delete.Location = new Point(414, 3);
            btn_delete.Name = "btn_delete";
            btn_delete.Size = new Size(101, 32);
            btn_delete.TabIndex = 3;
            btn_delete.Text = "Delete";
            btn_delete.UseVisualStyleBackColor = true;
            btn_delete.Click += btn_delete_Click;
            // 
            // btn_save
            // 
            btn_save.Location = new Point(225, 3);
            btn_save.Name = "btn_save";
            btn_save.Size = new Size(101, 32);
            btn_save.TabIndex = 2;
            btn_save.Text = "Save";
            btn_save.UseVisualStyleBackColor = true;
            btn_save.Click += btn_save_Click;
            // 
            // btn_add
            // 
            btn_add.Location = new Point(38, 3);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(101, 32);
            btn_add.TabIndex = 1;
            btn_add.Text = "Add New";
            btn_add.UseVisualStyleBackColor = true;
            btn_add.Click += btn_add_Click;
            // 
            // FormCustomer
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(759, 666);
            Controls.Add(panel3);
            Controls.Add(dataGridViewCustomers);
            Controls.Add(comboGender);
            Controls.Add(txtPhone);
            Controls.Add(label10);
            Controls.Add(txtAddress);
            Controls.Add(label9);
            Controls.Add(txtYearOfBirth);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(txtWeight);
            Controls.Add(label6);
            Controls.Add(txtHeight);
            Controls.Add(lbl_password);
            Controls.Add(txtCreditCard);
            Controls.Add(label4);
            Controls.Add(txtLastName);
            Controls.Add(label3);
            Controls.Add(txtFirstName);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Controls.Add(txtCustomerID);
            Name = "FormCustomer";
            Text = "Customer";
            Load += FormCustomer_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewCustomers).EndInit();
            ((System.ComponentModel.ISupportInitialize)customerBindingSource).EndInit();
            panel3.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel2;
        private Button btn_close;
        private Button btn_delete;
        private Button btn_save;
        private Button btn_add;
        private ComboBox comboGender;
        private TextBox txtPhone;
        private Label label10;
        private TextBox txtAddress;
        private Label label9;
        private TextBox txtYearOfBirth;
        private Label label8;
        private Label label7;
        private TextBox txtWeight;
        private Label label6;
        private TextBox txtHeight;
        private Label lbl_password;
        private TextBox txtCreditCard;
        private Label label4;
        private TextBox txtLastName;
        private Label label3;
        private TextBox txtFirstName;
        private Label label2;
        private Panel panel1;
        private TextBox txt_search_firstName;
        private Label label11;
        private TextBox txt_search_lastName;
        private Label label5;
        private Button btn_search;
        private Label label1;
        private TextBox txtCustomerID;
        private DataGridView dataGridViewCustomers;
        private DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn yearOfBirthDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn creditCardDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn genderDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn heightDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn weightDataGridViewTextBoxColumn;
        private BindingSource customerBindingSource;
        private Panel panel3;
      
    }
}