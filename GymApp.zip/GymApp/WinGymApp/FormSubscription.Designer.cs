﻿namespace WinGymApp
{
    partial class FormSubscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel2 = new Panel();
            btn_close = new Button();
            btn_delete = new Button();
            btn_save = new Button();
            btn_add = new Button();
            txtSubscriptionID = new TextBox();
            label1 = new Label();
            pickerStartDateTime = new DateTimePicker();
            label2 = new Label();
            label3 = new Label();
            pickerEndDateTime = new DateTimePicker();
            comboCustomerID = new ComboBox();
            label4 = new Label();
            label5 = new Label();
            txtCostWithVAT = new TextBox();
            panel1 = new Panel();
            picker_searchTo = new DateTimePicker();
            picker_searchFrom = new DateTimePicker();
            label11 = new Label();
            label6 = new Label();
            btn_search = new Button();
            dataGridViewSubscriptions = new DataGridView();
            subscriptionIdDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            startDateTimeDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            endDateTimeDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            costWithVATDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            customerIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            customerDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            subscriptionBindingSource = new BindingSource(components);
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSubscriptions).BeginInit();
            ((System.ComponentModel.ISupportInitialize)subscriptionBindingSource).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ActiveCaption;
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(btn_close);
            panel2.Controls.Add(btn_delete);
            panel2.Controls.Add(btn_save);
            panel2.Controls.Add(btn_add);
            panel2.Location = new Point(12, 12);
            panel2.Name = "panel2";
            panel2.Size = new Size(735, 45);
            panel2.TabIndex = 27;
            // 
            // btn_close
            // 
            btn_close.Location = new Point(590, 3);
            btn_close.Name = "btn_close";
            btn_close.Size = new Size(101, 32);
            btn_close.TabIndex = 4;
            btn_close.Text = "Close";
            btn_close.UseVisualStyleBackColor = true;
            btn_close.Click += btn_close_Click;
            // 
            // btn_delete
            // 
            btn_delete.Location = new Point(414, 3);
            btn_delete.Name = "btn_delete";
            btn_delete.Size = new Size(101, 32);
            btn_delete.TabIndex = 3;
            btn_delete.Text = "Delete";
            btn_delete.UseVisualStyleBackColor = true;
            btn_delete.Click += btn_delete_Click;
            // 
            // btn_save
            // 
            btn_save.Location = new Point(225, 3);
            btn_save.Name = "btn_save";
            btn_save.Size = new Size(101, 32);
            btn_save.TabIndex = 2;
            btn_save.Text = "Save";
            btn_save.UseVisualStyleBackColor = true;
            btn_save.Click += btn_save_Click;
            // 
            // btn_add
            // 
            btn_add.Location = new Point(38, 3);
            btn_add.Name = "btn_add";
            btn_add.Size = new Size(101, 32);
            btn_add.TabIndex = 1;
            btn_add.Text = "Add New";
            btn_add.UseVisualStyleBackColor = true;
            btn_add.Click += btn_add_Click;
            // 
            // txtSubscriptionID
            // 
            txtSubscriptionID.Location = new Point(105, 85);
            txtSubscriptionID.Name = "txtSubscriptionID";
            txtSubscriptionID.Size = new Size(215, 23);
            txtSubscriptionID.TabIndex = 30;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 88);
            label1.Name = "label1";
            label1.Size = new Size(87, 15);
            label1.TabIndex = 29;
            label1.Text = "Subscription ID";
            // 
            // pickerStartDateTime
            // 
            pickerStartDateTime.Location = new Point(455, 85);
            pickerStartDateTime.Name = "pickerStartDateTime";
            pickerStartDateTime.Size = new Size(233, 23);
            pickerStartDateTime.TabIndex = 31;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(387, 91);
            label2.Name = "label2";
            label2.Size = new Size(62, 15);
            label2.TabIndex = 32;
            label2.Text = "Start From";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(406, 156);
            label3.Name = "label3";
            label3.Size = new Size(43, 15);
            label3.TabIndex = 34;
            label3.Text = "Unti to";
            // 
            // pickerEndDateTime
            // 
            pickerEndDateTime.Location = new Point(455, 150);
            pickerEndDateTime.Name = "pickerEndDateTime";
            pickerEndDateTime.Size = new Size(233, 23);
            pickerEndDateTime.TabIndex = 33;
            // 
            // comboCustomerID
            // 
            comboCustomerID.FormattingEnabled = true;
            comboCustomerID.Location = new Point(105, 142);
            comboCustomerID.Name = "comboCustomerID";
            comboCustomerID.Size = new Size(215, 23);
            comboCustomerID.TabIndex = 35;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 150);
            label4.Name = "label4";
            label4.Size = new Size(73, 15);
            label4.TabIndex = 36;
            label4.Text = "Customer ID";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(406, 217);
            label5.Name = "label5";
            label5.Size = new Size(33, 15);
            label5.TabIndex = 37;
            label5.Text = "Price";
            // 
            // txtCostWithVAT
            // 
            txtCostWithVAT.Location = new Point(455, 214);
            txtCostWithVAT.Name = "txtCostWithVAT";
            txtCostWithVAT.Size = new Size(233, 23);
            txtCostWithVAT.TabIndex = 38;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(picker_searchTo);
            panel1.Controls.Add(picker_searchFrom);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(btn_search);
            panel1.Location = new Point(12, 243);
            panel1.Name = "panel1";
            panel1.Size = new Size(735, 60);
            panel1.TabIndex = 44;
            // 
            // picker_searchTo
            // 
            picker_searchTo.Location = new Point(272, 32);
            picker_searchTo.Name = "picker_searchTo";
            picker_searchTo.Size = new Size(233, 23);
            picker_searchTo.TabIndex = 33;
            // 
            // picker_searchFrom
            // 
            picker_searchFrom.Location = new Point(19, 32);
            picker_searchFrom.Name = "picker_searchFrom";
            picker_searchFrom.Size = new Size(233, 23);
            picker_searchFrom.TabIndex = 32;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(75, 8);
            label11.Name = "label11";
            label11.Size = new Size(85, 15);
            label11.TabIndex = 14;
            label11.Text = "Start From Day";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(323, 8);
            label6.Name = "label6";
            label6.Size = new Size(113, 15);
            label6.TabIndex = 8;
            label6.Text = "Until Start From Day";
            // 
            // btn_search
            // 
            btn_search.Location = new Point(595, 28);
            btn_search.Name = "btn_search";
            btn_search.Size = new Size(97, 27);
            btn_search.TabIndex = 0;
            btn_search.Text = "Search";
            btn_search.UseVisualStyleBackColor = true;
            btn_search.Click += btn_search_Click;
            // 
            // dataGridViewSubscriptions
            // 
            dataGridViewSubscriptions.AutoGenerateColumns = false;
            dataGridViewSubscriptions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewSubscriptions.Columns.AddRange(new DataGridViewColumn[] { subscriptionIdDataGridViewTextBoxColumn, startDateTimeDataGridViewTextBoxColumn, endDateTimeDataGridViewTextBoxColumn, costWithVATDataGridViewTextBoxColumn, customerIDDataGridViewTextBoxColumn, customerDataGridViewTextBoxColumn });
            dataGridViewSubscriptions.DataSource = subscriptionBindingSource;
            dataGridViewSubscriptions.Location = new Point(12, 319);
            dataGridViewSubscriptions.Name = "dataGridViewSubscriptions";
            dataGridViewSubscriptions.Size = new Size(735, 223);
            dataGridViewSubscriptions.TabIndex = 45;
            // 
            // subscriptionIdDataGridViewTextBoxColumn
            // 
            subscriptionIdDataGridViewTextBoxColumn.DataPropertyName = "SubscriptionId";
            subscriptionIdDataGridViewTextBoxColumn.HeaderText = "SubscriptionId";
            subscriptionIdDataGridViewTextBoxColumn.Name = "subscriptionIdDataGridViewTextBoxColumn";
            // 
            // startDateTimeDataGridViewTextBoxColumn
            // 
            startDateTimeDataGridViewTextBoxColumn.DataPropertyName = "StartDateTime";
            startDateTimeDataGridViewTextBoxColumn.HeaderText = "StartDateTime";
            startDateTimeDataGridViewTextBoxColumn.Name = "startDateTimeDataGridViewTextBoxColumn";
            // 
            // endDateTimeDataGridViewTextBoxColumn
            // 
            endDateTimeDataGridViewTextBoxColumn.DataPropertyName = "EndDateTime";
            endDateTimeDataGridViewTextBoxColumn.HeaderText = "EndDateTime";
            endDateTimeDataGridViewTextBoxColumn.Name = "endDateTimeDataGridViewTextBoxColumn";
            // 
            // costWithVATDataGridViewTextBoxColumn
            // 
            costWithVATDataGridViewTextBoxColumn.DataPropertyName = "CostWithVAT";
            costWithVATDataGridViewTextBoxColumn.HeaderText = "CostWithVAT";
            costWithVATDataGridViewTextBoxColumn.Name = "costWithVATDataGridViewTextBoxColumn";
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            customerIDDataGridViewTextBoxColumn.DataPropertyName = "CustomerID";
            customerIDDataGridViewTextBoxColumn.HeaderText = "CustomerID";
            customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            // 
            // customerDataGridViewTextBoxColumn
            // 
            customerDataGridViewTextBoxColumn.DataPropertyName = "Customer";
            customerDataGridViewTextBoxColumn.HeaderText = "Customer";
            customerDataGridViewTextBoxColumn.Name = "customerDataGridViewTextBoxColumn";
            // 
            // subscriptionBindingSource
            // 
            subscriptionBindingSource.DataSource = typeof(LibraryDB.Subscription);
            // 
            // FormSubscription
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(763, 546);
            Controls.Add(dataGridViewSubscriptions);
            Controls.Add(panel1);
            Controls.Add(txtCostWithVAT);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(comboCustomerID);
            Controls.Add(label3);
            Controls.Add(pickerEndDateTime);
            Controls.Add(label2);
            Controls.Add(pickerStartDateTime);
            Controls.Add(txtSubscriptionID);
            Controls.Add(label1);
            Controls.Add(panel2);
            Name = "FormSubscription";
            Text = "FormSubscription";
            Load += FormSubscription_Load;
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSubscriptions).EndInit();
            ((System.ComponentModel.ISupportInitialize)subscriptionBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel2;
        private Button btn_close;
        private Button btn_delete;
        private Button btn_save;
        private Button btn_add;
        private TextBox txtSubscriptionID;
        private Label label1;
        private DateTimePicker pickerStartDateTime;
        private Label label2;
        private Label label3;
        private DateTimePicker pickerEndDateTime;
        private ComboBox comboCustomerID;
        private Label label4;
        private Label label5;
        private TextBox txtCostWithVAT;
        private Panel panel1;
        private DateTimePicker picker_searchTo;
        private DateTimePicker picker_searchFrom;
        private Label label11;
        private Label label6;
        private Button btn_search;
        private DataGridView dataGridViewSubscriptions;
        private DataGridViewTextBoxColumn subscriptionIdDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn startDateTimeDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn endDateTimeDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn costWithVATDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn customerDataGridViewTextBoxColumn;
        private BindingSource subscriptionBindingSource;
    }
}