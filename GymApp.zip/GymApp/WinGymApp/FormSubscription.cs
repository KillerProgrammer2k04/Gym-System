﻿using LibraryDB;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinGymApp
{
    public partial class FormSubscription : Form
    {
        private Subscription newSubscription;

        public FormSubscription()
        {
            InitializeComponent();
        }

        private void FormSubscription_Load(object sender, EventArgs e)
        {
            LoadSubscriptionData();
            LoadCustomerIDs();
        }

        private void LoadSubscriptionData()
        {
            using (var context = new GymDBContext())
            {
                // Fetch data from the Subscriptions table
                var subscriptionData = context.Subscriptions.Include(s => s.Customer).ToList();

                // Bind the data to the BindingSource
                subscriptionBindingSource.DataSource = subscriptionData;

                // Bind the BindingSource to the DataGridView
                dataGridViewSubscriptions.DataSource = subscriptionBindingSource;

                // Bind each control to specific fields of the BindingSource
                txtSubscriptionID.DataBindings.Clear();
                txtCostWithVAT.DataBindings.Clear();
                comboCustomerID.DataBindings.Clear();
                pickerStartDateTime.DataBindings.Clear();
                pickerEndDateTime.DataBindings.Clear();

                txtSubscriptionID.DataBindings.Add("Text", subscriptionBindingSource, "SubscriptionId", true, DataSourceUpdateMode.OnPropertyChanged);
                txtCostWithVAT.DataBindings.Add("Text", subscriptionBindingSource, "CostWithVAT", true, DataSourceUpdateMode.OnPropertyChanged);
                comboCustomerID.DataBindings.Add("SelectedValue", subscriptionBindingSource, "CustomerID", true, DataSourceUpdateMode.OnPropertyChanged);
                pickerStartDateTime.DataBindings.Add("Value", subscriptionBindingSource, "StartDateTime", true, DataSourceUpdateMode.OnPropertyChanged);
                pickerEndDateTime.DataBindings.Add("Value", subscriptionBindingSource, "EndDateTime", true, DataSourceUpdateMode.OnPropertyChanged);
            }
        }

        private void LoadCustomerIDs()
        {
            using (var context = new GymDBContext())
            {
                var customers = context.Customers.ToList();
                comboCustomerID.DataSource = customers;
                comboCustomerID.DisplayMember = "LastName"; // Display last name or any other relevant field
                comboCustomerID.ValueMember = "CustomerID";
            }
        }


        private void btn_add_Click(object sender, EventArgs e)
        {
            // Clear the controls to prepare for adding a new record
            newSubscription = new Subscription();
            subscriptionBindingSource.Add(newSubscription);
            subscriptionBindingSource.MoveLast();

            txtSubscriptionID.Text = string.Empty;
            txtCostWithVAT.Text = string.Empty;
            comboCustomerID.SelectedIndex = -1;
            pickerStartDateTime.Value = DateTime.Now;
            pickerEndDateTime.Value = DateTime.Now;

            txtCostWithVAT.Focus();
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Add or update the subscription records
                    foreach (var subscription in subscriptionBindingSource.List.OfType<Subscription>())
                    {
                        // Check if SubscriptionId is empty (new record)
                        if (subscription.SubscriptionId == Guid.Empty)
                        {
                            subscription.SubscriptionId = Guid.NewGuid();
                            context.Subscriptions.Add(subscription);
                        }
                        else
                        {
                            context.Subscriptions.Update(subscription);
                        }
                    }

                    context.SaveChanges();
                    MessageBox.Show("Data saved successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (ValidationException valEx)
            {
                MessageBox.Show($"A validation error occurred: {valEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the current subscription record from the BindingSource
                    var currentSubscription = subscriptionBindingSource.Current as Subscription;
                    if (currentSubscription != null)
                    {
                        // Find the subscription record in the context
                        var subscriptionToDelete = context.Subscriptions.Find(currentSubscription.SubscriptionId);
                        if (subscriptionToDelete != null)
                        {
                            // Remove the subscription record from the context
                            context.Subscriptions.Remove(subscriptionToDelete);
                            context.SaveChanges();

                            // Remove the subscription record from the BindingSource
                            subscriptionBindingSource.RemoveCurrent();

                            MessageBox.Show("Record deleted successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Record not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No record selected to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the search criteria from the date pickers
                    DateTime searchFrom = picker_searchFrom.Value;
                    DateTime searchTo = picker_searchTo.Value;

                    // Fetch data from the Subscriptions table with the applied filters
                    var subscriptionData = context.Subscriptions.AsQueryable();

                    subscriptionData = subscriptionData.Where(s => s.StartDateTime >= searchFrom && s.StartDateTime <= searchTo);

                    // Bind the filtered data to the BindingSource
                    subscriptionBindingSource.DataSource = subscriptionData.ToList();

                    // Refresh the DataGridView
                    dataGridViewSubscriptions.DataSource = subscriptionBindingSource;
                    dataGridViewSubscriptions.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while searching: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
