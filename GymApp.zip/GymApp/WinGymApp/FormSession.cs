﻿using LibraryDB;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinGymApp
{
    public partial class FormSession : Form
    {
        private Session newSession;

        public FormSession()
        {
            InitializeComponent();
        }

        private void FormSession_Load(object sender, EventArgs e)
        {
            LoadSessionData();
            LoadTrainerIDs();
        }

        private void LoadSessionData()
        {
            using (var context = new GymDBContext())
            {
                // Fetch data from the Sessions table
                var sessionData = context.Sessions.Include(s => s.Trainer).ToList();

                // Bind the data to the BindingSource
                sessionBindingSource.DataSource = sessionData;

                // Bind the BindingSource to the DataGridView
                dataGridViewSessions.DataSource = sessionBindingSource;

                // Bind each control to specific fields of the BindingSource
                txtSessionID.DataBindings.Clear();
                comboTrainerID.DataBindings.Clear();
                pickerStartDateTime.DataBindings.Clear();
                pickerEndDateTime.DataBindings.Clear();

                txtSessionID.DataBindings.Add("Text", sessionBindingSource, "SessionID", true, DataSourceUpdateMode.OnPropertyChanged);
                comboTrainerID.DataBindings.Add("SelectedValue", sessionBindingSource, "TrainerID", true, DataSourceUpdateMode.OnPropertyChanged);
                pickerStartDateTime.DataBindings.Add("Value", sessionBindingSource, "StartDateTime", true, DataSourceUpdateMode.OnPropertyChanged);
                pickerEndDateTime.DataBindings.Add("Value", sessionBindingSource, "EndDateTime", true, DataSourceUpdateMode.OnPropertyChanged);
            }
        }

        private void LoadTrainerIDs()
        {
            using (var context = new GymDBContext())
            {
                var trainers = context.Trainers.ToList();
                comboTrainerID.DataSource = trainers;
                comboTrainerID.DisplayMember = "LastName"; // Display last name or any other relevant field
                comboTrainerID.ValueMember = "TrainerID";
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            // Clear the controls to prepare for adding a new record
            newSession = new Session();
            sessionBindingSource.Add(newSession);
            sessionBindingSource.MoveLast();

            txtSessionID.Text = string.Empty;
            comboTrainerID.SelectedIndex = -1;
            pickerStartDateTime.Value = DateTime.Now;
            pickerEndDateTime.Value = DateTime.Now;

            comboTrainerID.Focus();
        }


        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Add or update the session records
                    foreach (var session in sessionBindingSource.List.OfType<Session>())
                    {
                        // Check if SessionID is empty (new record)
                        if (session.SessionID == Guid.Empty)
                        {
                            session.SessionID = Guid.NewGuid();
                            context.Sessions.Add(session);
                        }
                        else
                        {
                            context.Sessions.Update(session);
                        }
                    }

                    context.SaveChanges();
                    MessageBox.Show("Data saved successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (ValidationException valEx)
            {
                MessageBox.Show($"A validation error occurred: {valEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the current session record from the BindingSource
                    var currentSession = sessionBindingSource.Current as Session;
                    if (currentSession != null)
                    {
                        // Find the session record in the context
                        var sessionToDelete = context.Sessions.Find(currentSession.SessionID);
                        if (sessionToDelete != null)
                        {
                            // Remove the session record from the context
                            context.Sessions.Remove(sessionToDelete);
                            context.SaveChanges();

                            // Remove the session record from the BindingSource
                            sessionBindingSource.RemoveCurrent();

                            MessageBox.Show("Record deleted successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Record not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No record selected to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (DbUpdateException dbEx)
            {
                MessageBox.Show($"A database update error occurred: {dbEx.InnerException?.Message ?? dbEx.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new GymDBContext())
                {
                    // Get the search criteria from the date pickers
                    DateTime searchFrom = picker_searchFrom.Value;
                    DateTime searchTo = picker_searchTo.Value;

                    // Fetch data from the Sessions table with the applied filters
                    var sessionData = context.Sessions.AsQueryable();

                    sessionData = sessionData.Where(s => s.StartDateTime >= searchFrom && s.StartDateTime <= searchTo);

                    // Bind the filtered data to the BindingSource
                    sessionBindingSource.DataSource = sessionData.ToList();

                    // Refresh the DataGridView
                    dataGridViewSessions.DataSource = sessionBindingSource;
                    dataGridViewSessions.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while searching: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
