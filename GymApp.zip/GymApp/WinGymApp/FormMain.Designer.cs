﻿namespace WinGymApp
{
    partial class FormMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_login = new Button();
            btn_logout = new Button();
            btn_staff = new Button();
            btn_customer = new Button();
            btn_subscription = new Button();
            btn_session = new Button();
            btn_exit = new Button();
            btn_trainer = new Button();
            SuspendLayout();
            // 
            // btn_login
            // 
            btn_login.Cursor = Cursors.Hand;
            btn_login.Location = new Point(35, 12);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(126, 44);
            btn_login.TabIndex = 0;
            btn_login.Text = "Login";
            btn_login.UseVisualStyleBackColor = true;
            btn_login.Click += btn_login_Click;
            // 
            // btn_logout
            // 
            btn_logout.Cursor = Cursors.Hand;
            btn_logout.Location = new Point(369, 12);
            btn_logout.Name = "btn_logout";
            btn_logout.Size = new Size(126, 44);
            btn_logout.TabIndex = 1;
            btn_logout.Text = "Logout";
            btn_logout.UseVisualStyleBackColor = true;
            btn_logout.Click += btn_logout_Click;
            // 
            // btn_staff
            // 
            btn_staff.Cursor = Cursors.Hand;
            btn_staff.Location = new Point(35, 101);
            btn_staff.Name = "btn_staff";
            btn_staff.Size = new Size(126, 44);
            btn_staff.TabIndex = 2;
            btn_staff.Text = "Staff";
            btn_staff.UseVisualStyleBackColor = true;
            btn_staff.Click += btn_staff_Click;
            // 
            // btn_customer
            // 
            btn_customer.Cursor = Cursors.Hand;
            btn_customer.Location = new Point(201, 101);
            btn_customer.Name = "btn_customer";
            btn_customer.Size = new Size(126, 44);
            btn_customer.TabIndex = 3;
            btn_customer.Text = "Customer";
            btn_customer.UseVisualStyleBackColor = true;
            btn_customer.Click += btn_customer_Click;
            // 
            // btn_subscription
            // 
            btn_subscription.Cursor = Cursors.Hand;
            btn_subscription.Location = new Point(35, 198);
            btn_subscription.Name = "btn_subscription";
            btn_subscription.Size = new Size(126, 44);
            btn_subscription.TabIndex = 4;
            btn_subscription.Text = "Subscription";
            btn_subscription.UseVisualStyleBackColor = true;
            btn_subscription.Click += btn_subscription_Click;
            // 
            // btn_session
            // 
            btn_session.Cursor = Cursors.Hand;
            btn_session.Location = new Point(201, 198);
            btn_session.Name = "btn_session";
            btn_session.Size = new Size(126, 44);
            btn_session.TabIndex = 5;
            btn_session.Text = "Session";
            btn_session.UseVisualStyleBackColor = true;
            btn_session.Click += btn_session_Click;
            // 
            // btn_exit
            // 
            btn_exit.Cursor = Cursors.Hand;
            btn_exit.Location = new Point(369, 198);
            btn_exit.Name = "btn_exit";
            btn_exit.Size = new Size(126, 44);
            btn_exit.TabIndex = 7;
            btn_exit.Text = "Exit";
            btn_exit.UseVisualStyleBackColor = true;
            btn_exit.Click += btn_exit_Click;
            // 
            // btn_trainer
            // 
            btn_trainer.Cursor = Cursors.Hand;
            btn_trainer.Location = new Point(369, 101);
            btn_trainer.Name = "btn_trainer";
            btn_trainer.Size = new Size(126, 44);
            btn_trainer.TabIndex = 8;
            btn_trainer.Text = "Trainer";
            btn_trainer.UseVisualStyleBackColor = true;
            btn_trainer.Click += btn_trainer_Click;
            // 
            // FormMain
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(523, 254);
            Controls.Add(btn_trainer);
            Controls.Add(btn_exit);
            Controls.Add(btn_session);
            Controls.Add(btn_subscription);
            Controls.Add(btn_customer);
            Controls.Add(btn_staff);
            Controls.Add(btn_logout);
            Controls.Add(btn_login);
            Name = "FormMain";
            Text = "Welcome to Gym";
            ResumeLayout(false);
        }

        #endregion

        private Button btn_login;
        private Button btn_logout;
        private Button btn_staff;
        private Button btn_customer;
        private Button btn_subscription;
        private Button btn_session;
        private Button btn_exit;
        private Button btn_trainer;
    }
}
